namespace Models;
class Cachorro : Animal
{
    public override void EmitirSom()
    {
        Console.WriteLine("au");
    }
}