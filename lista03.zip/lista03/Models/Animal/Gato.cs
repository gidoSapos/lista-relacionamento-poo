namespace Models;
class Gato : Animal
{
    public override void EmitirSom()
    {
        Console.WriteLine("MIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAU");
    }
}