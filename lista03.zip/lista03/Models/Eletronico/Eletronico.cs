namespace Models;
class Eletronico
{
    public virtual void Ligar()
    {
        Console.WriteLine("Ligando eletrônico... ALta potência cuidado com o choque ZIUUUUUU");
    }
}