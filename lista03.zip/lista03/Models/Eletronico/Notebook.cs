namespace Models;

class Notebook : Eletronico
{
    public override void Ligar()
    {
        Console.WriteLine("Ligando o notebook. De 15000000000 reaus");
    }
}
