namespace Models;
class Smartphone : Eletronico
{
    public override void Ligar()
    {
        Console.WriteLine("Ligando o Xiomi. 坏蛋混蛋 滚蛋 -- 王八蛋");
    }
}