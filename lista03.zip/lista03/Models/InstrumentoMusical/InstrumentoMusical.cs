namespace Models;
class InstrumentoMusical
{
    public virtual void Tocar()
    {
        Console.WriteLine("pew pew pew zumzum.");
    }
}