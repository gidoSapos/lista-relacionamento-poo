namespace Models;
class Piano : InstrumentoMusical
{
    public override void Tocar()
    {
        Console.WriteLine("pling pling pling plong");
    }
}