namespace Models;

class Guitarra : InstrumentoMusical
{
    public override void Tocar()
    {
        Console.WriteLine("*solo de rock*");
    }
}