namespace Models;
abstract class Forma
{
    public abstract double CalcularArea();
}
