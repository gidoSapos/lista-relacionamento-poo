namespace Models;
class Moto : Veiculo
{
    public bool TemPartidaEletrica { get; set; }
}