namespace Models;
class Carro : Veiculo
{
    public int Portas { get; set; }
}
