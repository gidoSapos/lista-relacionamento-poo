namespace Models;
class Veiculo
{
    public string ?Marca { get; set; }
    public int Ano { get; set; }
}
